import { Component } from '@angular/core';

@Component({
  selector: 'app-is-empty',
  templateUrl: './is-empty.component.html',
  styleUrl: './is-empty.component.scss'
})
export class IsEmptyComponent {

}
